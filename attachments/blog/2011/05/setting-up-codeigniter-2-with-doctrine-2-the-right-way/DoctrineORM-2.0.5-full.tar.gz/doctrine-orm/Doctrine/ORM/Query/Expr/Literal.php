<?php

namespace Doctrine\ORM\Query\Expr;

class Literal extends Base
{
    protected $_preSeparator = '';
    protected $_postSeparator = '';
}
