``` ini

BenchmarkDotNet=v0.12.1, OS=Windows 10.0.19042
Intel Core i7-1065G7 CPU 1.30GHz, 1 CPU, 8 logical and 4 physical cores
.NET Core SDK=5.0.100
  [Host]        : .NET Core 3.1.9 (CoreCLR 4.700.20.47201, CoreFX 4.700.20.47203), X64 RyuJIT
  .NET 4.8      : .NET Framework 4.8 (4.8.4250.0), X64 RyuJIT
  .NET Core 3.1 : .NET Core 3.1.9 (CoreCLR 4.700.20.47201, CoreFX 4.700.20.47203), X64 RyuJIT
  .NET Core 5.0 : .NET Core 5.0.0 (CoreCLR 5.0.20.51904, CoreFX 5.0.20.51904), X64 RyuJIT


```
|                         Type |           Method |           Job |       Runtime |         Mean |      Error |       StdDev |    Ratio | RatioSD |
|----------------------------- |----------------- |-------------- |-------------- |-------------:|-----------:|-------------:|---------:|--------:|
| ActivateBaselinePackageAsset |  NewPackageAsset |      .NET 4.8 |      .NET 4.8 |     12.63 ns |   0.219 ns |     0.205 ns |     1.00 |    0.00 |
|    ActivateOfT&lt;PackageAsset&gt; |       Reflection |      .NET 4.8 |      .NET 4.8 |    189.54 ns |   2.043 ns |     1.811 ns |    15.00 |    0.32 |
|   ActivateType&lt;PackageAsset&gt; |       Reflection |      .NET 4.8 |      .NET 4.8 |    184.05 ns |   3.457 ns |     3.233 ns |    14.58 |    0.30 |
|    ActivateOfT&lt;PackageAsset&gt; | ReflectionCached |      .NET 4.8 |      .NET 4.8 |    118.02 ns |   1.623 ns |     1.518 ns |     9.35 |    0.21 |
|   ActivateType&lt;PackageAsset&gt; | ReflectionCached |      .NET 4.8 |      .NET 4.8 |    112.41 ns |   1.744 ns |     1.632 ns |     8.91 |    0.25 |
|    ActivateOfT&lt;PackageAsset&gt; |             Emit |      .NET 4.8 |      .NET 4.8 | 50,060.25 ns | 949.214 ns | 1,015.648 ns | 3,977.97 |   93.15 |
|   ActivateType&lt;PackageAsset&gt; |             Emit |      .NET 4.8 |      .NET 4.8 | 48,924.70 ns | 524.139 ns |   464.635 ns | 3,871.65 |   61.17 |
|    ActivateOfT&lt;PackageAsset&gt; |       EmitCached |      .NET 4.8 |      .NET 4.8 |     22.04 ns |   0.217 ns |     0.193 ns |     1.74 |    0.03 |
|   ActivateType&lt;PackageAsset&gt; |       EmitCached |      .NET 4.8 |      .NET 4.8 |     19.46 ns |   0.421 ns |     0.394 ns |     1.54 |    0.04 |
|    ActivateOfT&lt;PackageAsset&gt; |        Activator |      .NET 4.8 |      .NET 4.8 |     62.10 ns |   0.702 ns |     0.657 ns |     4.92 |    0.11 |
|   ActivateType&lt;PackageAsset&gt; |        Activator |      .NET 4.8 |      .NET 4.8 |     51.69 ns |   0.569 ns |     0.504 ns |     4.09 |    0.07 |
|    ActivateOfT&lt;PackageAsset&gt; |             NewT |      .NET 4.8 |      .NET 4.8 |     61.91 ns |   0.569 ns |     0.475 ns |     4.90 |    0.09 |
|                              |                  |               |               |              |            |              |          |         |
| ActivateBaselinePackageAsset |  NewPackageAsset | .NET Core 3.1 | .NET Core 3.1 |     13.18 ns |   0.188 ns |     0.176 ns |     1.00 |    0.00 |
|    ActivateOfT&lt;PackageAsset&gt; |       Reflection | .NET Core 3.1 | .NET Core 3.1 |    140.15 ns |   1.622 ns |     1.437 ns |    10.64 |    0.19 |
|   ActivateType&lt;PackageAsset&gt; |       Reflection | .NET Core 3.1 | .NET Core 3.1 |    134.93 ns |   1.081 ns |     0.959 ns |    10.25 |    0.19 |
|    ActivateOfT&lt;PackageAsset&gt; | ReflectionCached | .NET Core 3.1 | .NET Core 3.1 |     89.34 ns |   1.060 ns |     0.939 ns |     6.78 |    0.10 |
|   ActivateType&lt;PackageAsset&gt; | ReflectionCached | .NET Core 3.1 | .NET Core 3.1 |     88.09 ns |   1.579 ns |     1.477 ns |     6.69 |    0.16 |
|    ActivateOfT&lt;PackageAsset&gt; |             Emit | .NET Core 3.1 | .NET Core 3.1 | 53,353.06 ns | 680.355 ns |   636.405 ns | 4,049.46 |   65.61 |
|   ActivateType&lt;PackageAsset&gt; |             Emit | .NET Core 3.1 | .NET Core 3.1 | 54,386.42 ns | 441.474 ns |   412.956 ns | 4,128.04 |   66.07 |
|    ActivateOfT&lt;PackageAsset&gt; |       EmitCached | .NET Core 3.1 | .NET Core 3.1 |     17.24 ns |   0.230 ns |     0.192 ns |     1.31 |    0.02 |
|   ActivateType&lt;PackageAsset&gt; |       EmitCached | .NET Core 3.1 | .NET Core 3.1 |     14.31 ns |   0.327 ns |     0.322 ns |     1.09 |    0.03 |
|    ActivateOfT&lt;PackageAsset&gt; |        Activator | .NET Core 3.1 | .NET Core 3.1 |     42.77 ns |   0.535 ns |     0.501 ns |     3.25 |    0.05 |
|   ActivateType&lt;PackageAsset&gt; |        Activator | .NET Core 3.1 | .NET Core 3.1 |     39.86 ns |   0.381 ns |     0.357 ns |     3.03 |    0.05 |
|    ActivateOfT&lt;PackageAsset&gt; |             NewT | .NET Core 3.1 | .NET Core 3.1 |     43.71 ns |   0.924 ns |     1.233 ns |     3.36 |    0.09 |
|                              |                  |               |               |              |            |              |          |         |
| ActivateBaselinePackageAsset |  NewPackageAsset | .NET Core 5.0 | .NET Core 5.0 |     13.03 ns |   0.283 ns |     0.265 ns |     1.00 |    0.00 |
|    ActivateOfT&lt;PackageAsset&gt; |       Reflection | .NET Core 5.0 | .NET Core 5.0 |    129.22 ns |   2.562 ns |     2.516 ns |     9.93 |    0.21 |
|   ActivateType&lt;PackageAsset&gt; |       Reflection | .NET Core 5.0 | .NET Core 5.0 |    122.18 ns |   2.031 ns |     1.900 ns |     9.38 |    0.19 |
|    ActivateOfT&lt;PackageAsset&gt; | ReflectionCached | .NET Core 5.0 | .NET Core 5.0 |     75.95 ns |   0.971 ns |     0.908 ns |     5.83 |    0.17 |
|   ActivateType&lt;PackageAsset&gt; | ReflectionCached | .NET Core 5.0 | .NET Core 5.0 |     74.27 ns |   0.841 ns |     0.746 ns |     5.70 |    0.12 |
|    ActivateOfT&lt;PackageAsset&gt; |             Emit | .NET Core 5.0 | .NET Core 5.0 | 48,703.52 ns | 815.649 ns |   723.052 ns | 3,737.73 |   94.87 |
|   ActivateType&lt;PackageAsset&gt; |             Emit | .NET Core 5.0 | .NET Core 5.0 | 48,727.37 ns | 737.366 ns |   689.732 ns | 3,741.05 |  111.20 |
|    ActivateOfT&lt;PackageAsset&gt; |       EmitCached | .NET Core 5.0 | .NET Core 5.0 |     16.92 ns |   0.341 ns |     0.319 ns |     1.30 |    0.04 |
|   ActivateType&lt;PackageAsset&gt; |       EmitCached | .NET Core 5.0 | .NET Core 5.0 |     14.32 ns |   0.338 ns |     0.376 ns |     1.10 |    0.05 |
|    ActivateOfT&lt;PackageAsset&gt; |        Activator | .NET Core 5.0 | .NET Core 5.0 |     40.32 ns |   0.538 ns |     0.503 ns |     3.09 |    0.08 |
|   ActivateType&lt;PackageAsset&gt; |        Activator | .NET Core 5.0 | .NET Core 5.0 |     35.69 ns |   0.391 ns |     0.326 ns |     2.73 |    0.05 |
|    ActivateOfT&lt;PackageAsset&gt; |             NewT | .NET Core 5.0 | .NET Core 5.0 |     39.30 ns |   0.636 ns |     0.595 ns |     3.02 |    0.07 |
