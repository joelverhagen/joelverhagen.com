``` ini

BenchmarkDotNet=v0.12.1, OS=Windows 10.0.19042
Intel Core i7-1065G7 CPU 1.30GHz, 1 CPU, 8 logical and 4 physical cores
.NET Core SDK=5.0.100
  [Host]        : .NET Core 3.1.9 (CoreCLR 4.700.20.47201, CoreFX 4.700.20.47203), X64 RyuJIT
  .NET 4.8      : .NET Framework 4.8 (4.8.4250.0), X64 RyuJIT
  .NET Core 3.1 : .NET Core 3.1.9 (CoreCLR 4.700.20.47201, CoreFX 4.700.20.47203), X64 RyuJIT
  .NET Core 5.0 : .NET Core 5.0.0 (CoreCLR 5.0.20.51904, CoreFX 5.0.20.51904), X64 RyuJIT


```
|                   Type |           Method |           Job |       Runtime |          Mean |       Error |        StdDev |     Ratio | RatioSD |
|----------------------- |----------------- |-------------- |-------------- |--------------:|------------:|--------------:|----------:|--------:|
| ActivateBaselineObject |        NewObject |      .NET 4.8 |      .NET 4.8 |      2.189 ns |   0.0724 ns |     0.0678 ns |      1.00 |    0.00 |
|    ActivateOfT&lt;Object&gt; |       Reflection |      .NET 4.8 |      .NET 4.8 |    158.273 ns |   2.3660 ns |     2.2132 ns |     72.36 |    2.21 |
|   ActivateType&lt;Object&gt; |       Reflection |      .NET 4.8 |      .NET 4.8 |    151.502 ns |   2.6249 ns |     2.1919 ns |     69.01 |    2.14 |
|    ActivateOfT&lt;Object&gt; | ReflectionCached |      .NET 4.8 |      .NET 4.8 |     87.373 ns |   0.6866 ns |     0.6086 ns |     39.96 |    1.23 |
|   ActivateType&lt;Object&gt; | ReflectionCached |      .NET 4.8 |      .NET 4.8 |     85.249 ns |   1.6951 ns |     1.6648 ns |     39.01 |    1.44 |
|    ActivateOfT&lt;Object&gt; |             Emit |      .NET 4.8 |      .NET 4.8 | 36,529.718 ns | 597.5794 ns |   664.2079 ns | 16,730.76 |  603.62 |
|   ActivateType&lt;Object&gt; |             Emit |      .NET 4.8 |      .NET 4.8 | 36,275.659 ns | 354.4515 ns |   331.5542 ns | 16,589.13 |  617.35 |
|    ActivateOfT&lt;Object&gt; |       EmitCached |      .NET 4.8 |      .NET 4.8 |      5.809 ns |   0.1821 ns |     0.1949 ns |      2.66 |    0.12 |
|   ActivateType&lt;Object&gt; |       EmitCached |      .NET 4.8 |      .NET 4.8 |      4.007 ns |   0.1347 ns |     0.1260 ns |      1.83 |    0.07 |
|    ActivateOfT&lt;Object&gt; |        Activator |      .NET 4.8 |      .NET 4.8 |     46.035 ns |   0.9534 ns |     0.8918 ns |     21.05 |    0.87 |
|   ActivateType&lt;Object&gt; |        Activator |      .NET 4.8 |      .NET 4.8 |     35.544 ns |   0.6972 ns |     0.6848 ns |     16.26 |    0.59 |
|    ActivateOfT&lt;Object&gt; |             NewT |      .NET 4.8 |      .NET 4.8 |     46.212 ns |   0.9035 ns |     0.8451 ns |     21.13 |    0.78 |
|                        |                  |               |               |               |             |               |           |         |
| ActivateBaselineObject |        NewObject | .NET Core 3.1 | .NET Core 3.1 |      2.772 ns |   0.0550 ns |     0.0515 ns |      1.00 |    0.00 |
|    ActivateOfT&lt;Object&gt; |       Reflection | .NET Core 3.1 | .NET Core 3.1 |    121.116 ns |   1.3368 ns |     1.1850 ns |     43.65 |    0.67 |
|   ActivateType&lt;Object&gt; |       Reflection | .NET Core 3.1 | .NET Core 3.1 |    124.305 ns |   1.6385 ns |     1.3682 ns |     44.70 |    0.90 |
|    ActivateOfT&lt;Object&gt; | ReflectionCached | .NET Core 3.1 | .NET Core 3.1 |     75.563 ns |   0.9678 ns |     0.8579 ns |     27.23 |    0.52 |
|   ActivateType&lt;Object&gt; | ReflectionCached | .NET Core 3.1 | .NET Core 3.1 |     73.042 ns |   0.7317 ns |     0.6110 ns |     26.27 |    0.55 |
|    ActivateOfT&lt;Object&gt; |             Emit | .NET Core 3.1 | .NET Core 3.1 | 46,076.222 ns | 915.7890 ns | 1,158.1798 ns | 16,485.74 |  604.49 |
|   ActivateType&lt;Object&gt; |             Emit | .NET Core 3.1 | .NET Core 3.1 | 46,132.958 ns | 559.6396 ns |   523.4872 ns | 16,643.73 |  285.73 |
|    ActivateOfT&lt;Object&gt; |       EmitCached | .NET Core 3.1 | .NET Core 3.1 |      4.812 ns |   0.0903 ns |     0.0844 ns |      1.74 |    0.05 |
|   ActivateType&lt;Object&gt; |       EmitCached | .NET Core 3.1 | .NET Core 3.1 |      3.987 ns |   0.1068 ns |     0.0999 ns |      1.44 |    0.05 |
|    ActivateOfT&lt;Object&gt; |        Activator | .NET Core 3.1 | .NET Core 3.1 |     31.642 ns |   0.5543 ns |     0.5185 ns |     11.42 |    0.27 |
|   ActivateType&lt;Object&gt; |        Activator | .NET Core 3.1 | .NET Core 3.1 |     26.707 ns |   0.2327 ns |     0.2063 ns |      9.63 |    0.21 |
|    ActivateOfT&lt;Object&gt; |             NewT | .NET Core 3.1 | .NET Core 3.1 |     30.756 ns |   0.6466 ns |     0.7446 ns |     11.14 |    0.39 |
|                        |                  |               |               |               |             |               |           |         |
| ActivateBaselineObject |        NewObject | .NET Core 5.0 | .NET Core 5.0 |      2.713 ns |   0.0725 ns |     0.0678 ns |      1.00 |    0.00 |
|    ActivateOfT&lt;Object&gt; |       Reflection | .NET Core 5.0 | .NET Core 5.0 |    108.113 ns |   1.8091 ns |     1.6037 ns |     39.93 |    1.33 |
|   ActivateType&lt;Object&gt; |       Reflection | .NET Core 5.0 | .NET Core 5.0 |    108.309 ns |   1.5940 ns |     1.4910 ns |     39.95 |    1.24 |
|    ActivateOfT&lt;Object&gt; | ReflectionCached | .NET Core 5.0 | .NET Core 5.0 |     61.327 ns |   1.0655 ns |     0.9967 ns |     22.61 |    0.52 |
|   ActivateType&lt;Object&gt; | ReflectionCached | .NET Core 5.0 | .NET Core 5.0 |     60.765 ns |   0.7950 ns |     0.7437 ns |     22.41 |    0.61 |
|    ActivateOfT&lt;Object&gt; |             Emit | .NET Core 5.0 | .NET Core 5.0 | 40,410.243 ns | 566.6665 ns |   530.0602 ns | 14,903.96 |  424.96 |
|   ActivateType&lt;Object&gt; |             Emit | .NET Core 5.0 | .NET Core 5.0 | 41,507.698 ns | 802.9174 ns |   751.0495 ns | 15,307.12 |  419.53 |
|    ActivateOfT&lt;Object&gt; |       EmitCached | .NET Core 5.0 | .NET Core 5.0 |      5.744 ns |   0.1787 ns |     0.2447 ns |      2.08 |    0.09 |
|   ActivateType&lt;Object&gt; |       EmitCached | .NET Core 5.0 | .NET Core 5.0 |      3.864 ns |   0.0747 ns |     0.0699 ns |      1.43 |    0.05 |
|    ActivateOfT&lt;Object&gt; |        Activator | .NET Core 5.0 | .NET Core 5.0 |     31.204 ns |   0.4425 ns |     0.4139 ns |     11.51 |    0.30 |
|   ActivateType&lt;Object&gt; |        Activator | .NET Core 5.0 | .NET Core 5.0 |     23.104 ns |   0.2711 ns |     0.2536 ns |      8.52 |    0.24 |
|    ActivateOfT&lt;Object&gt; |             NewT | .NET Core 5.0 | .NET Core 5.0 |     30.558 ns |   0.5005 ns |     0.4681 ns |     11.27 |    0.31 |
