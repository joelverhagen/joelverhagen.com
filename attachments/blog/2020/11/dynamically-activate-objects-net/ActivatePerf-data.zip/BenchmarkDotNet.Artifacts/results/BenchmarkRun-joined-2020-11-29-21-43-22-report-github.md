``` ini

BenchmarkDotNet=v0.12.1, OS=Windows 10.0.19042
Intel Core i7-1065G7 CPU 1.30GHz, 1 CPU, 8 logical and 4 physical cores
.NET Core SDK=5.0.100
  [Host]        : .NET Core 3.1.9 (CoreCLR 4.700.20.47201, CoreFX 4.700.20.47203), X64 RyuJIT
  .NET 4.8      : .NET Framework 4.8 (4.8.4250.0), X64 RyuJIT
  .NET Core 3.1 : .NET Core 3.1.9 (CoreCLR 4.700.20.47201, CoreFX 4.700.20.47203), X64 RyuJIT
  .NET Core 5.0 : .NET Core 5.0.0 (CoreCLR 5.0.20.51904, CoreFX 5.0.20.51904), X64 RyuJIT


```
|                          Type |           Method |           Job |       Runtime |           Mean |         Error |        StdDev |    Ratio | RatioSD |
|------------------------------ |----------------- |-------------- |-------------- |---------------:|--------------:|--------------:|---------:|--------:|
| ActivateBaselineStringBuilder | NewStringBuilder |      .NET 4.8 |      .NET 4.8 |      13.153 ns |     0.1763 ns |     0.1650 ns |     1.00 |    0.00 |
|    ActivateOfT&lt;StringBuilder&gt; |       Reflection |      .NET 4.8 |      .NET 4.8 |     203.031 ns |     2.1424 ns |     2.0040 ns |    15.44 |    0.17 |
|   ActivateType&lt;StringBuilder&gt; |       Reflection |      .NET 4.8 |      .NET 4.8 |     200.904 ns |     3.8267 ns |     3.5795 ns |    15.28 |    0.30 |
|    ActivateOfT&lt;StringBuilder&gt; | ReflectionCached |      .NET 4.8 |      .NET 4.8 |     100.066 ns |     1.1150 ns |     1.0430 ns |     7.61 |    0.10 |
|   ActivateType&lt;StringBuilder&gt; | ReflectionCached |      .NET 4.8 |      .NET 4.8 |      97.844 ns |     1.8815 ns |     1.7600 ns |     7.44 |    0.17 |
|    ActivateOfT&lt;StringBuilder&gt; |             Emit |      .NET 4.8 |      .NET 4.8 | 118,592.712 ns | 1,492.4321 ns | 1,323.0022 ns | 9,017.59 |  154.96 |
|   ActivateType&lt;StringBuilder&gt; |             Emit |      .NET 4.8 |      .NET 4.8 | 119,820.437 ns | 1,441.2343 ns | 1,277.6167 ns | 9,111.40 |  179.66 |
|    ActivateOfT&lt;StringBuilder&gt; |       EmitCached |      .NET 4.8 |      .NET 4.8 |      16.541 ns |     0.2598 ns |     0.2303 ns |     1.26 |    0.02 |
|   ActivateType&lt;StringBuilder&gt; |       EmitCached |      .NET 4.8 |      .NET 4.8 |      13.931 ns |     0.1945 ns |     0.1819 ns |     1.06 |    0.02 |
|    ActivateOfT&lt;StringBuilder&gt; |        Activator |      .NET 4.8 |      .NET 4.8 |      58.943 ns |     0.6743 ns |     0.6308 ns |     4.48 |    0.07 |
|   ActivateType&lt;StringBuilder&gt; |        Activator |      .NET 4.8 |      .NET 4.8 |      50.744 ns |     1.0368 ns |     1.1939 ns |     3.86 |    0.12 |
|    ActivateOfT&lt;StringBuilder&gt; |             NewT |      .NET 4.8 |      .NET 4.8 |      58.435 ns |     0.9497 ns |     0.8883 ns |     4.44 |    0.09 |
|                               |                  |               |               |                |               |               |          |         |
| ActivateBaselineStringBuilder | NewStringBuilder | .NET Core 3.1 | .NET Core 3.1 |       8.898 ns |     0.1467 ns |     0.1372 ns |     1.00 |    0.00 |
|    ActivateOfT&lt;StringBuilder&gt; |       Reflection | .NET Core 3.1 | .NET Core 3.1 |     169.320 ns |     2.5374 ns |     2.3734 ns |    19.03 |    0.37 |
|   ActivateType&lt;StringBuilder&gt; |       Reflection | .NET Core 3.1 | .NET Core 3.1 |     170.479 ns |     1.5980 ns |     1.4947 ns |    19.16 |    0.31 |
|    ActivateOfT&lt;StringBuilder&gt; | ReflectionCached | .NET Core 3.1 | .NET Core 3.1 |      83.613 ns |     1.6001 ns |     1.4185 ns |     9.40 |    0.24 |
|   ActivateType&lt;StringBuilder&gt; | ReflectionCached | .NET Core 3.1 | .NET Core 3.1 |      82.299 ns |     0.9531 ns |     0.8915 ns |     9.25 |    0.19 |
|    ActivateOfT&lt;StringBuilder&gt; |             Emit | .NET Core 3.1 | .NET Core 3.1 |  73,993.576 ns | 1,391.0952 ns | 1,301.2313 ns | 8,317.68 |  190.06 |
|   ActivateType&lt;StringBuilder&gt; |             Emit | .NET Core 3.1 | .NET Core 3.1 |  73,510.679 ns |   980.6283 ns |   917.2803 ns | 8,263.69 |  173.59 |
|    ActivateOfT&lt;StringBuilder&gt; |       EmitCached | .NET Core 3.1 | .NET Core 3.1 |      11.720 ns |     0.1997 ns |     0.1868 ns |     1.32 |    0.02 |
|   ActivateType&lt;StringBuilder&gt; |       EmitCached | .NET Core 3.1 | .NET Core 3.1 |       9.959 ns |     0.1897 ns |     0.1775 ns |     1.12 |    0.03 |
|    ActivateOfT&lt;StringBuilder&gt; |        Activator | .NET Core 3.1 | .NET Core 3.1 |      38.094 ns |     0.8256 ns |     0.8834 ns |     4.30 |    0.11 |
|   ActivateType&lt;StringBuilder&gt; |        Activator | .NET Core 3.1 | .NET Core 3.1 |      34.083 ns |     0.5463 ns |     0.5111 ns |     3.83 |    0.09 |
|    ActivateOfT&lt;StringBuilder&gt; |             NewT | .NET Core 3.1 | .NET Core 3.1 |      38.128 ns |     0.4967 ns |     0.4147 ns |     4.28 |    0.09 |
|                               |                  |               |               |                |               |               |          |         |
| ActivateBaselineStringBuilder | NewStringBuilder | .NET Core 5.0 | .NET Core 5.0 |       8.993 ns |     0.1466 ns |     0.1300 ns |     1.00 |    0.00 |
|    ActivateOfT&lt;StringBuilder&gt; |       Reflection | .NET Core 5.0 | .NET Core 5.0 |     157.382 ns |     2.0263 ns |     1.8954 ns |    17.49 |    0.33 |
|   ActivateType&lt;StringBuilder&gt; |       Reflection | .NET Core 5.0 | .NET Core 5.0 |     155.496 ns |     2.9492 ns |     2.7587 ns |    17.29 |    0.42 |
|    ActivateOfT&lt;StringBuilder&gt; | ReflectionCached | .NET Core 5.0 | .NET Core 5.0 |      72.919 ns |     1.5263 ns |     1.9846 ns |     8.24 |    0.20 |
|   ActivateType&lt;StringBuilder&gt; | ReflectionCached | .NET Core 5.0 | .NET Core 5.0 |      73.411 ns |     1.5103 ns |     1.5510 ns |     8.16 |    0.24 |
|    ActivateOfT&lt;StringBuilder&gt; |             Emit | .NET Core 5.0 | .NET Core 5.0 |  67,317.125 ns |   584.3267 ns |   546.5795 ns | 7,486.45 |  135.27 |
|   ActivateType&lt;StringBuilder&gt; |             Emit | .NET Core 5.0 | .NET Core 5.0 |  67,939.058 ns |   783.0251 ns |   732.4422 ns | 7,549.32 |  102.50 |
|    ActivateOfT&lt;StringBuilder&gt; |       EmitCached | .NET Core 5.0 | .NET Core 5.0 |      11.872 ns |     0.2982 ns |     0.2789 ns |     1.32 |    0.03 |
|   ActivateType&lt;StringBuilder&gt; |       EmitCached | .NET Core 5.0 | .NET Core 5.0 |      10.203 ns |     0.2635 ns |     0.2588 ns |     1.13 |    0.04 |
|    ActivateOfT&lt;StringBuilder&gt; |        Activator | .NET Core 5.0 | .NET Core 5.0 |      36.373 ns |     0.7455 ns |     0.7656 ns |     4.03 |    0.12 |
|   ActivateType&lt;StringBuilder&gt; |        Activator | .NET Core 5.0 | .NET Core 5.0 |      31.395 ns |     0.3050 ns |     0.2853 ns |     3.49 |    0.06 |
|    ActivateOfT&lt;StringBuilder&gt; |             NewT | .NET Core 5.0 | .NET Core 5.0 |      36.555 ns |     0.4703 ns |     0.4400 ns |     4.07 |    0.07 |
