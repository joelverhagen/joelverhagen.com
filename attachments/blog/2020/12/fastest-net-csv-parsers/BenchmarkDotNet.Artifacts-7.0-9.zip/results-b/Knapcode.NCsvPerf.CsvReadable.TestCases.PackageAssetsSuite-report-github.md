```

BenchmarkDotNet v0.13.9+228a464e8be6c580ad9408e98f18813f6407fb5a, Windows 11 (10.0.22621.2428/22H2/2022Update/SunValley2)
AMD Ryzen 9 3950X, 1 CPU, 32 logical and 16 physical cores
.NET SDK 7.0.402
  [Host]     : .NET 7.0.12 (7.0.1223.47720), X64 RyuJIT AVX2
  Job-NQTYWN : .NET 7.0.12 (7.0.1223.47720), X64 RyuJIT AVX2

InvocationCount=1  IterationCount=6  LaunchCount=1  
UnrollFactor=1  WarmupCount=2  

```
| Method               | LineCount | Mean       | Error    | StdDev  | Gen0       | Gen1       | Gen2      | Allocated |
|--------------------- |---------- |-----------:|---------:|--------:|-----------:|-----------:|----------:|----------:|
| RecordParser         | 1000000   | 1,761.0 ms | 24.94 ms | 8.89 ms | 34000.0000 | 33000.0000 | 4000.0000 | 260.66 MB |
| RecordParserParallel | 1000000   |   825.5 ms | 14.10 ms | 3.66 ms | 38000.0000 | 37000.0000 | 4000.0000 | 279.61 MB |
