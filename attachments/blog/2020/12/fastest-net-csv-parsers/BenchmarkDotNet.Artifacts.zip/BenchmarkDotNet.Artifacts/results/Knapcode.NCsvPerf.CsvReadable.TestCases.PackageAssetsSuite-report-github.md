``` ini

BenchmarkDotNet=v0.12.1, OS=Windows 10.0.19042
AMD Ryzen 9 3950X, 1 CPU, 32 logical and 16 physical cores
.NET Core SDK=5.0.100
  [Host]     : .NET Core 3.1.9 (CoreCLR 4.700.20.47201, CoreFX 4.700.20.47203), X64 RyuJIT
  DefaultJob : .NET Core 3.1.9 (CoreCLR 4.700.20.47201, CoreFX 4.700.20.47203), X64 RyuJIT


```
|                      Method | LineCount |             Mean |          Error |         StdDev |
|---------------------------- |---------- |-----------------:|---------------:|---------------:|
|          **CsvHelperCsvReader** |         **0** |         **50.20 μs** |       **0.498 μs** |       **0.466 μs** |
| CsvTextFieldParserCsvReader |         0 |         42.93 μs |       0.266 μs |       0.222 μs |
|      FastCsvParserCsvReader |         0 |         70.75 μs |       0.219 μs |       0.205 μs |
|          HomeGrownCsvReader |         0 |         43.26 μs |       0.180 μs |       0.141 μs |
|         LumenWorksCsvReader |         0 |         47.74 μs |       0.852 μs |       0.755 μs |
|        MgholamFastCsvReader |         0 |         68.64 μs |       0.149 μs |       0.124 μs |
|              NRecoCsvReader |         0 |         54.85 μs |       0.226 μs |       0.189 μs |
|   ServiceStackTextCsvReader |         0 |         42.57 μs |       0.425 μs |       0.397 μs |
|       ReallySimpleCsvReader |         0 |         42.77 μs |       0.397 μs |       0.352 μs |
|        StringSplitCsvReader |         0 |         42.71 μs |       0.292 μs |       0.259 μs |
|               TinyCsvReader |         0 |         42.60 μs |       0.389 μs |       0.325 μs |
|          **CsvHelperCsvReader** |         **1** |         **57.58 μs** |       **0.411 μs** |       **0.385 μs** |
| CsvTextFieldParserCsvReader |         1 |         50.02 μs |       0.309 μs |       0.274 μs |
|      FastCsvParserCsvReader |         1 |         76.75 μs |       0.325 μs |       0.304 μs |
|          HomeGrownCsvReader |         1 |         50.92 μs |       0.240 μs |       0.213 μs |
|         LumenWorksCsvReader |         1 |         55.22 μs |       1.020 μs |       1.175 μs |
|        MgholamFastCsvReader |         1 |         74.88 μs |       0.158 μs |       0.148 μs |
|              NRecoCsvReader |         1 |         59.16 μs |       0.857 μs |       0.802 μs |
|   ServiceStackTextCsvReader |         1 |         51.02 μs |       0.376 μs |       0.351 μs |
|       ReallySimpleCsvReader |         1 |        107.68 μs |       0.535 μs |       0.474 μs |
|        StringSplitCsvReader |         1 |         50.28 μs |       0.518 μs |       0.433 μs |
|               TinyCsvReader |         1 |         54.39 μs |       0.178 μs |       0.158 μs |
|          **CsvHelperCsvReader** |        **10** |        **116.75 μs** |       **0.441 μs** |       **0.412 μs** |
| CsvTextFieldParserCsvReader |        10 |         76.33 μs |       0.188 μs |       0.176 μs |
|      FastCsvParserCsvReader |        10 |         96.22 μs |       0.107 μs |       0.095 μs |
|          HomeGrownCsvReader |        10 |         73.62 μs |       0.390 μs |       0.364 μs |
|         LumenWorksCsvReader |        10 |         88.58 μs |       0.295 μs |       0.262 μs |
|        MgholamFastCsvReader |        10 |         88.13 μs |       0.181 μs |       0.169 μs |
|              NRecoCsvReader |        10 |         77.51 μs |       0.230 μs |       0.215 μs |
|   ServiceStackTextCsvReader |        10 |         63.61 μs |       0.395 μs |       0.330 μs |
|       ReallySimpleCsvReader |        10 |        389.29 μs |       2.433 μs |       2.276 μs |
|        StringSplitCsvReader |        10 |         59.56 μs |       0.220 μs |       0.195 μs |
|               TinyCsvReader |        10 |        107.08 μs |       0.466 μs |       0.389 μs |
|          **CsvHelperCsvReader** |       **100** |        **608.18 μs** |       **1.239 μs** |       **1.099 μs** |
| CsvTextFieldParserCsvReader |       100 |        384.58 μs |       1.336 μs |       1.185 μs |
|      FastCsvParserCsvReader |       100 |        281.57 μs |       1.253 μs |       1.172 μs |
|          HomeGrownCsvReader |       100 |        321.88 μs |       0.909 μs |       0.759 μs |
|         LumenWorksCsvReader |       100 |        345.04 μs |       0.937 μs |       0.877 μs |
|        MgholamFastCsvReader |       100 |        221.73 μs |       0.524 μs |       0.490 μs |
|              NRecoCsvReader |       100 |        244.34 μs |       2.497 μs |       2.336 μs |
|   ServiceStackTextCsvReader |       100 |        262.91 μs |       1.033 μs |       0.966 μs |
|       ReallySimpleCsvReader |       100 |      3,168.11 μs |      14.541 μs |      13.602 μs |
|        StringSplitCsvReader |       100 |        202.31 μs |       0.510 μs |       0.477 μs |
|               TinyCsvReader |       100 |        588.59 μs |       2.325 μs |       2.175 μs |
|          **CsvHelperCsvReader** |      **1000** |      **5,679.55 μs** |      **38.118 μs** |      **35.656 μs** |
| CsvTextFieldParserCsvReader |      1000 |      3,464.75 μs |      19.934 μs |      18.647 μs |
|      FastCsvParserCsvReader |      1000 |      2,203.70 μs |      13.451 μs |      12.582 μs |
|          HomeGrownCsvReader |      1000 |      2,615.24 μs |      17.229 μs |      16.116 μs |
|         LumenWorksCsvReader |      1000 |      3,153.97 μs |      16.162 μs |      15.118 μs |
|        MgholamFastCsvReader |      1000 |      1,439.88 μs |       4.529 μs |       4.015 μs |
|              NRecoCsvReader |      1000 |      1,837.38 μs |      10.984 μs |      10.275 μs |
|   ServiceStackTextCsvReader |      1000 |      2,295.68 μs |       4.123 μs |       3.219 μs |
|       ReallySimpleCsvReader |      1000 |     30,310.06 μs |     179.895 μs |     168.274 μs |
|        StringSplitCsvReader |      1000 |      1,652.18 μs |       3.554 μs |       3.150 μs |
|               TinyCsvReader |      1000 |      5,741.70 μs |      29.269 μs |      27.378 μs |
|          **CsvHelperCsvReader** |     **10000** |     **77,009.14 μs** |     **401.655 μs** |     **356.057 μs** |
| CsvTextFieldParserCsvReader |     10000 |     51,073.03 μs |     653.376 μs |     611.168 μs |
|      FastCsvParserCsvReader |     10000 |     39,193.67 μs |     613.026 μs |     573.425 μs |
|          HomeGrownCsvReader |     10000 |     40,944.53 μs |     439.674 μs |     411.271 μs |
|         LumenWorksCsvReader |     10000 |     46,484.61 μs |     818.265 μs |     765.406 μs |
|        MgholamFastCsvReader |     10000 |     21,730.18 μs |     264.950 μs |     234.871 μs |
|              NRecoCsvReader |     10000 |     31,890.34 μs |     244.819 μs |     217.026 μs |
|   ServiceStackTextCsvReader |     10000 |     40,421.58 μs |     639.747 μs |     598.420 μs |
|       ReallySimpleCsvReader |     10000 |    313,169.95 μs |     629.569 μs |     588.900 μs |
|        StringSplitCsvReader |     10000 |     36,162.92 μs |     713.483 μs |     849.350 μs |
|               TinyCsvReader |     10000 |     70,567.04 μs |   1,395.621 μs |   1,370.687 μs |
|          **CsvHelperCsvReader** |    **100000** |    **792,783.47 μs** |   **8,943.787 μs** |   **8,366.024 μs** |
| CsvTextFieldParserCsvReader |    100000 |    543,291.61 μs |   5,778.473 μs |   5,405.188 μs |
|      FastCsvParserCsvReader |    100000 |    365,200.16 μs |   1,540.393 μs |   1,365.519 μs |
|          HomeGrownCsvReader |    100000 |    413,031.47 μs |   1,708.153 μs |   1,597.808 μs |
|         LumenWorksCsvReader |    100000 |    586,657.46 μs |   8,654.952 μs |   8,095.847 μs |
|        MgholamFastCsvReader |    100000 |    302,559.78 μs |   2,077.232 μs |   1,621.766 μs |
|              NRecoCsvReader |    100000 |    340,973.21 μs |   3,438.370 μs |   3,216.253 μs |
|   ServiceStackTextCsvReader |    100000 |    389,892.03 μs |   6,718.863 μs |   6,284.828 μs |
|       ReallySimpleCsvReader |    100000 |  3,199,973.24 μs |  12,962.366 μs |  12,125.005 μs |
|        StringSplitCsvReader |    100000 |    312,244.09 μs |   6,087.832 μs |   7,010.757 μs |
|               TinyCsvReader |    100000 |    796,052.86 μs |   7,991.899 μs |   6,673.598 μs |
|          **CsvHelperCsvReader** |   **1000000** |  **7,753,068.68 μs** |  **39,794.348 μs** |  **35,276.653 μs** |
| CsvTextFieldParserCsvReader |   1000000 |  5,311,378.79 μs |  35,997.891 μs |  30,059.869 μs |
|      FastCsvParserCsvReader |   1000000 |  4,090,570.05 μs |  32,795.884 μs |  30,677.290 μs |
|          HomeGrownCsvReader |   1000000 |  4,613,020.50 μs |  46,160.683 μs |  43,178.732 μs |
|         LumenWorksCsvReader |   1000000 |  5,403,152.15 μs |  24,408.695 μs |  21,637.673 μs |
|        MgholamFastCsvReader |   1000000 |  3,418,042.44 μs |  64,410.166 μs |  63,259.395 μs |
|              NRecoCsvReader |   1000000 |  3,649,808.13 μs |  51,946.251 μs |  48,590.556 μs |
|   ServiceStackTextCsvReader |   1000000 |  4,242,369.70 μs |  33,565.641 μs |  31,397.321 μs |
|       ReallySimpleCsvReader |   1000000 | 31,170,867.61 μs | 149,760.103 μs | 132,758.430 μs |
|        StringSplitCsvReader |   1000000 |  3,413,183.09 μs |  49,114.454 μs |  45,941.691 μs |
|               TinyCsvReader |   1000000 |  7,891,362.47 μs |  62,345.470 μs |  58,317.991 μs |
