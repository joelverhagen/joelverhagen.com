﻿namespace Xilium.CefGlue
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Xilium.CefGlue.Interop;

    public abstract unsafe partial class CefUserData
    {
    }
}
