﻿//
// This file manually written from cef/include/internal/cef_types.h.
// C API name: cef_log_severity_t.
//
namespace Xilium.CefGlue
{
	public enum CefNavigationType
	{
		LinkClicked = 0,
		FormSubmitted,
		BackForwarD,
		Reload,
		FormResubmitted,
		Other,
	}
}
