import pygame, os, random

## Preferences ##

PREFERENCES = {
	'auto-deselect': True
}

## Global Variables ##

SHAPES = ['diamond', 'oval', 'squiggly']
COLORS = ['green', 'purple', 'red']
PATTERNS = ['empty', 'solid', 'striped']

IMAGES = [] # holds all of the image objects to minimize disk reads

CARD_RATIO = 2.5/3.5 # width to height
FIGURE_SIZE = (60, 30) # based on image size and should not change
CARD_SIZE = [0, 0] # both elements are calculated
PADDING = [0, 10] # first element is calculated, second element is variable
CARD_SPACING = 4 # width of the spacing between each card
CARD_BORDER = 4 # width of the border on the card
MARGIN = 10 # spacing around all content and the edge of the window

CARD_SIZE[1] = 3*FIGURE_SIZE[1]+5*PADDING[1]
CARD_SIZE[0] = int(CARD_SIZE[1]*CARD_RATIO)
PADDING[0] = int((CARD_SIZE[0]-FIGURE_SIZE[0])/2)

class Label(object):
	def __init__(self, text, width, height, fontSize):
		self.text = text
		self.width = width
		self.height = height
		self.fontSize = fontSize
		
		verdana = pygame.font.match_font('Verdana')
		self.font = pygame.font.Font(verdana, fontSize)
		self.textObject = self.font.render(self.text, 1, (255, 255, 255))
		
		if self.textObject.get_width() + 12 > self.width:
			self.width = self.textObject.get_width() + 12
		if self.textObject.get_height() + 12 > self.height:
			self.height = self.textObject.get_height() + 12
		
		self.surface = pygame.Surface((self.width, self.height))
		
		self.rect = self.drawBackground((0, 0, 0))
		self.drawText()
	
	def setText(self, text):
		self.drawBackground((0, 0, 0))
		
		self.text = text
		self.textObject = self.font.render(self.text, 1, (255, 255, 255))
		self.drawText()
	
	def drawText(self):
		self.surface.blit(self.textObject, self.textObject.get_rect(centerx = self.surface.get_width()/2, centery = self.surface.get_height()/2))
	
	def drawBackground(self, color):
		rect = pygame.draw.rect(self.surface, (50, 50, 50), (0, 0, self.width, self.height))
		pygame.draw.rect(self.surface, color, (2, 2, self.width-4, self.height-4))
		
		return rect

class Button(object):
	def __init__(self, text, width, height, fontSize):
		self.text = text
		self.width = width
		self.height = height
		
		self.id = '' # for identifying what button this is
		
		self.hovered = False
		self.clicked = False
		
		verdana = pygame.font.match_font('Verdana')
		self.font = pygame.font.Font(verdana, fontSize)
		self.textObject = self.font.render(self.text, 1, (0, 0, 0))
		
		if self.textObject.get_width() + 12 > self.width:
			self.width = self.textObject.get_width() + 12
		if self.textObject.get_height() + 12 > self.height:
			self.height = self.textObject.get_height() + 12
		
		self.surface = pygame.Surface((self.width, self.height))
		
		self.textPosition = self.textObject.get_rect(centerx = self.surface.get_width()/2, centery = self.surface.get_height()/2)
		
		self.rect = self.drawBackground((225, 225, 225))
		self.drawText()
	
	def drawText(self):
		self.surface.blit(self.textObject, self.textPosition)
	
	def drawBackground(self, color):
		rect = pygame.draw.rect(self.surface, (50, 50, 50), (0, 0, self.width, self.height))
		pygame.draw.rect(self.surface, color, (2, 2, self.width-4, self.height-4))
		
		return rect
	
	def click(self):
		return
	
	def hoverOn(self): # returns True if needs update
		if not self.hovered:
			self.hovered = True
			self.drawBackground((250, 250, 150))
			self.drawText()
			return True
		return False
	
	def hoverOff(self): # returns True if needs update
		if self.hovered:
			self.hovered = False
			self.drawBackground((225, 225, 225))
			self.drawText()
			return True
		return False

class Card(object):
	def __init__(self, shape, color, pattern, number):
		self.shape = shape
		self.color = color
		self.pattern = pattern
		self.number = number
		
		self.surface = pygame.Surface((CARD_SIZE[0], CARD_SIZE[1]))
		self.rect = pygame.draw.rect(self.surface, (0, 0, 0), (0, 0, CARD_SIZE[0], CARD_SIZE[1]))
		
		self.selected = False
		
		self.draw()
	
	def draw(self):
		pygame.draw.rect(self.surface, (255, 255, 255), (CARD_BORDER, CARD_BORDER, CARD_SIZE[0]-CARD_BORDER*2, CARD_SIZE[1]-CARD_BORDER*2))
		
		for i in range(self.number+1): 
			image, rect = IMAGES[self.shape*9+self.color*3+self.pattern*1]
			x = PADDING[0]
			y = ((PADDING[1]+FIGURE_SIZE[1])/2)*(2-self.number)+PADDING[1]*(1+i)+FIGURE_SIZE[1]*i
			self.surface.blit(image, (x, y))
	
	def click(self):
		if self.selected:
			pygame.draw.rect(self.surface, (0, 0, 0), (0, 0, CARD_SIZE[0], CARD_SIZE[1]))
			self.selected = False
		else:
			pygame.draw.rect(self.surface, (255, 0, 0), (0, 0, CARD_SIZE[0], CARD_SIZE[1]))
			self.selected = True
		self.draw()
	
	def hoverOn(self):
		return
	
	def hoverOff(self):
		return
	
	def __str__(self):
		return 'Card('+str(SHAPES[self.shape])+', '+str(COLORS[self.color])+', '+str(PATTERNS[self.pattern])+', '+str(self.number+1)+')'
		# return 'Card('+str(self.shape)+', '+str(self.color)+', '+str(self.pattern)+', '+str(self.number)+')'

class Deck(object):
	def __init__(self):
		self.cards = []
		for shape in range(3):
			for color in range(3):
				for pattern in range(3):
					for number in range(3):
						self.cards.append(Card(shape, color, pattern, number))
	
	def drawCards(self, count):
		drawn = []
		for i in range(count):
			if len(self.cards) == 0:
				return drawn
			card = self.cards.pop(random.randint(0, len(self.cards)-1))
			drawn.append(card)
		return drawn

class Set(object):
	def __init__(self, title, width, height, framerate):
		self.initialize(title, width, height, framerate)
		
		self.drawMainMenu()
		
		self.start() # starts the update loop
	
	def initialize(self, title, width, height, framerate):
		pygame.init()
		self.running = False
		
		self.icon = pygame.Surface((32, 32))
		self.icon.fill((255, 255, 255))
		iconImage, iconRect = loadImage('icon.png', True)
		self.icon.blit(iconImage, (0, 0))
		pygame.display.set_icon(self.icon)
		
		self.screen = pygame.display.set_mode((width, height))
		
		pygame.display.set_caption(title) # sets the title of the window
		self.clock = pygame.time.Clock() # sets up the clock for framerate throttling
		
		self.title = title
		self.width = width
		self.height = height
		self.framerate = framerate
		
		self.drawAreas = [] # holds rectangles that need to be updated on the screen
		self.hovered = False # holds the current object that is being hovered
		
		self.controls = [] # holds the UI or controls
		
		self.mode = 0 # 0 for main menu, 1 for single player, 2 for multiplayer
	
	def drawMainMenu(self):
		self.mode = 0
		newButton = Button('Single Player', 300, 70, 28)
		newButton.rect.x = (self.width/2)-150 # set x coordinate for the button
		newButton.rect.y = 200 # set y coordinate for the button
		newButton.id = 'singleplayerButton'
		self.blit(newButton)
		self.controls.append(newButton)
		
		newButton = Button('Multiplayer', 300, 70, 28)
		newButton.rect.x = (self.width/2)-150 # set x coordinate for the button
		newButton.rect.y = 300 # set y coordinate for the button
		newButton.id = 'multiplayerButton'
		self.blit(newButton)
		self.controls.append(newButton)
		
		newButton = Button('Exit', 300, 70, 28)
		newButton.rect.x = (self.width/2)-150 # set x coordinate for the button
		newButton.rect.y = 400 # set y coordinate for the button
		newButton.id = 'exitButton'
		self.blit(newButton)
		self.controls.append(newButton)
		
	def drawGame(self):
		self.mode = 1
		self.screen.fill((0, 0, 0))
		
		loadAllImages() # loads all individual images into memory
		
		self.score = 0
		self.holes = []
		
		self.emptySpace = Card(0, 0, 0, 0)
		self.emptySpace.surface = pygame.Surface((CARD_SIZE[0], CARD_SIZE[1]))
		self.emptySpace.rect = pygame.draw.rect(self.emptySpace.surface, (0, 0, 0), (0, 0, CARD_SIZE[0], CARD_SIZE[1]))
		
		self.selected = [] # cards that have been selected (max 3)
		
		self.deck = Deck() # generates the 81 card deck
		self.table = self.deck.drawCards(12) # draws the starting 12 cards from the deck
		self.ensureSet()
		
		self.drawGameControls() # draws the controls
		
		self.drawTable() # draws the cards
	
	def ensureSet(self):
		while not self.findSet() and len(self.deck.cards) > 0: # ensure that there is atleast one set in play
			self.action('drawButton')
		
	def drawGameControls(self): # set up controls
		setButton = Button('Set!', 100, 40, 24)
		setButton.rect.x = 10 # set x coordinate for the button
		setButton.rect.y = 500 # set y coordinate for the button
		setButton.id = 'setButton'
		self.blit(setButton)
		self.controls.append(setButton)
		
		# findButton = Button('Find Set', 140, 40, 24)
		# findButton.rect.x = 120 # set x coordinate for the button
		# findButton.rect.y = 500 # set y coordinate for the button
		# findButton.id = 'findButton'
		# self.blit(findButton)
		# self.controls.append(findButton)
		
		deselectButton = Button('Deselect', 140, 40, 24)
		deselectButton.rect.x = 120 # set x coordinate for the button
		deselectButton.rect.y = 500 # set y coordinate for the button
		deselectButton.id = 'deselectButton'
		self.blit(deselectButton)
		self.controls.append(deselectButton)
		
		# drawButton = Button('Draw 3', 140, 40, 24)
		# drawButton.rect.x = 270 # set x coordinate for the button
		# drawButton.rect.y = 500 # set y coordinate for the button
		# drawButton.id = 'drawButton'
		# self.blit(drawButton)
		# self.controls.append(drawButton)
		
		mainmenuButton = Button('Main Menu', 150, 40, 24)
		mainmenuButton.rect.x = self.width-160 # set x coordinate for the button
		mainmenuButton.rect.y = 500 # set y coordinate for the button
		mainmenuButton.id = 'mainmenuButton'
		self.blit(mainmenuButton)
		self.controls.append(mainmenuButton)
		
		self.scoreLabel = Label('Score: 0', 150, 40, 24)
		self.scoreLabel.rect.x = 270
		self.scoreLabel.rect.y = 500
		self.blit(self.scoreLabel)
	
	def blit(self, object): # blit the object to the screen and add to update queue
		self.screen.blit(object.surface, (object.rect.x, object.rect.y))
		self.drawAreas.append((object.rect.x, object.rect.y, object.rect.width, object.rect.height))
	
	def calculateCardPosition(self, input, coordinates = False): # takes a numerical position for a card on the table and converts it to coordinates, or vice versa. Numerical position starts at zero.
		if coordinates:
			x = (input[0]-MARGIN)/(CARD_SIZE[0]+CARD_SPACING)
			y = (input[1]-MARGIN)/(CARD_SIZE[1]+CARD_SPACING)
			return 3*x+y
		else:
			x = (input/3)*CARD_SIZE[0]+(input/3)*CARD_SPACING+MARGIN
			y = (input%3)*CARD_SIZE[1]+(input%3)*CARD_SPACING+MARGIN
			return (x, y)
	
	def drawTable(self): # systematically draw all cards in the table
		for i in range(len(self.table)):
			coordinates = self.calculateCardPosition(i)
			self.table[i].rect.x = coordinates[0]
			self.table[i].rect.y = coordinates[1]
			self.blit(self.table[i])
	
	def deselectCards(self): # deselect all cards
		for card in self.selected:
			card.click()
			self.blit(card)
		self.selected = []
	
	def findSet(self, randomSet = True): # returns three cards that are a valid set and are on the table
		sets = []
		for cardA in self.table:
			for cardB in self.table:
				for cardC in self.table:
					if cardA == cardB or cardA == cardC or cardB == cardC: # do not allow the same card in a set
						continue
					if self.checkSet([cardA, cardB, cardC]):
						sets.append([cardA, cardB, cardC])
		if randomSet:
			random.shuffle(sets)
		if len(sets) > 0:
			return sets[0]
		else:
			False
	
	def getLowestHole(self):
		if len(self.holes) > 0:
			lowestHole = self.holes[0]
			for hole in self.holes[1:]:
				if hole[2] < lowestHole[2]:
					lowestHole = hole
			return lowestHole
		else:
			return False
	
	def addCard(self, card):
		if len(self.holes) > 0:
			hole = self.getLowestHole()
			self.holes.remove(hole)
			location = hole[2]
			x = hole[0]
			y = hole[1]
		else:
			location = len(self.table)
			x, y = self.calculateCardPosition(location)
		card.rect.x = x
		card.rect.y = y
		self.table.insert(location, card)
		self.blit(card)
	
	def removeCard(self, card):
		try:
			position = self.calculateCardPosition((card.rect.x, card.rect.y), True)
		except ValueError:
			return False
		self.table.remove(card)
		self.emptySpace.rect.x = card.rect.x
		self.emptySpace.rect.y = card.rect.y
		self.blit(self.emptySpace)
		self.holes.append((card.rect.x, card.rect.y, position))
	
	def handleKey(self, key):
		if self.mode == 0:
			if key == pygame.K_ESCAPE or key == pygame.K_e: # (E)xit
				self.action('exitButton')
			elif key == pygame.K_s: # (S)ingle Player
				self.action('singleplayerButton')
			elif key == pygame.K_m: # (M)ultiplayer
				self.action('multiplayerButton')
			return
		
		if self.mode == 1:
			if key == pygame.K_RETURN: # Enter = Find Set
				self.action('setButton')
				return
			elif key == pygame.K_ESCAPE: # Left CTRL button
				self.action('mainmenuButton')
				return
			elif key == pygame.K_RCTRL: # Left CTRL button
				self.action('findButton')
				return
			elif key == pygame.K_LSHIFT or key == pygame.K_RSHIFT: # either SHIFT key deselects the cards
				self.action('deselectButton')
				return
			keys = {pygame.K_q: 0, pygame.K_a: 1, pygame.K_z: 2, pygame.K_w: 3, pygame.K_s: 4, pygame.K_x: 5, pygame.K_e: 6, pygame.K_d: 7, pygame.K_c: 8, pygame.K_r: 9, pygame.K_f: 10, pygame.K_v: 11, pygame.K_t: 12, pygame.K_g: 13, pygame.K_b: 14, pygame.K_y: 15, pygame.K_h: 16, pygame.K_n: 17, pygame.K_u: 18, pygame.K_j: 19, pygame.K_m: 20}
			if len(self.selected) <= 3 and key in keys:
				keyCard = False
				for card in self.table:
					if self.calculateCardPosition((card.rect.x, card.rect.y), True) == keys[key]:
						keyCard = card
				if not keyCard:
					return
				if keyCard.selected:
					try:
						self.selected.remove(keyCard)
					except:
						pass
				else:
					if len(self.selected) == 3:
						return
					else:
						self.selected.append(keyCard)
				keyCard.click()
				self.blit(keyCard)
			return
	
	def clearScreen(self):
		self.controls = []
		self.drawAreas = []
		self.hovered = False
		
		clear = pygame.Surface((self.width, self.height))
		clear.fill((0, 0, 0))
		
		self.screen.blit(clear, (0, 0))
		self.drawAreas.append((0, 0, self.width, self.height))
	
	def handleClick(self, pos):
		for control in self.controls:
			if control.rect.collidepoint(pos):
				control.click()
				self.blit(control)
				self.action(control.id)
				return
		
		if self.mode == 1:
			for card in self.table:
				if card.rect.collidepoint(pos):
					if card.selected: # card is already selected, therefore deselect
						self.selected.remove(card)
					elif len(self.selected) < 3: # card is not selected, therefore select
						self.selected.append(card)
					else: # card is not selected, but 3 are already selected
						return
					card.click()
					self.blit(card)
					return
	
	def removeSet(self, set):
		self.deselectCards()
		for card in set:
			self.removeCard(card)
		if len(self.table) < 12:
			newCards = self.deck.drawCards(3)
			
			for card in newCards:
				self.addCard(card)
	
	def action(self, id):
		if id == 'setButton':
			if len(self.selected) == 3:
				if self.checkSet(self.selected):
					self.removeSet(self.selected)
					self.score += 1
					self.scoreLabel.setText('Score: '+str(self.score))
					self.blit(self.scoreLabel)
					self.ensureSet()
				else:
					if PREFERENCES['auto-deselect']:
						self.deselectCards()
		elif id == 'findButton':
			set = self.findSet()
			if set is not None:
				self.deselectCards()
				self.selected = set
				for card in set:
					card.click()
					self.blit(card)
		elif id == 'deselectButton':
			self.deselectCards()
		elif id == 'drawButton':
			if len(self.table) <= 18:
				newCards = self.deck.drawCards(3)
				for card in newCards:
					self.addCard(card)
		elif id == 'exitButton':
			self.running = False
		elif id == 'singleplayerButton':
			self.clearScreen()
			self.drawGame()
		elif id == 'multiplayerButton':
			self.clearScreen()
		elif id == 'mainmenuButton':
			self.clearScreen()
			self.drawMainMenu()
	
	def handleHover(self, pos):
		if self.hovered != False and not self.hovered.rect.collidepoint(pos):
			update = self.hovered.hoverOff()
			if update:
				self.blit(self.hovered)
			self.hovered = False
		
		for control in self.controls:
			if control.rect.collidepoint(pos) and control != self.hovered:
				self.hovered = control
				update = control.hoverOn()
				if update:
					self.blit(control)
		
		if self.mode == 1:
			for card in self.table:
				if card.rect.collidepoint(pos) and card != self.hovered:
					self.hovered = card
					update = card.hoverOn()
					if update:
						self.blit(card)
		
	def checkSet(self, cards):
		if len(cards) != 3:
			return False
		if (cards[0].shape == cards[1].shape and cards[0].shape == cards[2].shape) or (cards[0].shape != cards[1].shape and cards[1].shape != cards[2].shape and cards[0].shape != cards[2].shape):
			if (cards[0].color == cards[1].color and cards[0].color == cards[2].color) or (cards[0].color != cards[1].color and cards[1].color != cards[2].color and cards[0].color != cards[2].color):
				if (cards[0].pattern == cards[1].pattern and cards[0].pattern == cards[2].pattern) or (cards[0].pattern != cards[1].pattern and cards[1].pattern != cards[2].pattern and cards[0].pattern != cards[2].pattern):
					if (cards[0].number == cards[1].number and cards[0].number == cards[2].number) or (cards[0].number != cards[1].number and cards[1].number != cards[2].number and cards[0].number != cards[2].number):
						return True
		return False
	
	def start(self):
		self.running = True
		
		while self.running:
			self.clock.tick(self.framerate) # maintain frame rate
			for event in pygame.event.get(): # handle events
				if event.type == pygame.QUIT:
					self.running = False
					break
				if event.type == pygame.MOUSEBUTTONUP:
					if event.button == 1:
						self.handleClick(event.pos)
				if event.type == pygame.MOUSEMOTION:
					self.handleHover(event.pos)
				if event.type == pygame.KEYUP:
					self.handleKey(event.key)
			
			if self.drawAreas: # update areas that need to be updated
				pygame.display.update(self.drawAreas)
				self.drawAreas = []
		
		pygame.quit()

def find(needle, haystack):
	for i in range(len(haystack)):
		if haystack[i] == needle:
			return i

def loadAllImages():
	for shape in range(3):
		for color in range(3):
			for pattern in range(3):
				IMAGES.append(loadImage(SHAPES[shape]+'_'+COLORS[color]+'_'+PATTERNS[pattern]+'.png'))

def loadImage(filename, skipAlpha = False):
	path = os.path.join('resources', filename)
	try:
		image = pygame.image.load(path)
		if not skipAlpha:
			if image.get_alpha() is None:
				image = image.convert()
			else:
				image = image.convert_alpha()
	except pygame.error, message:
		raise SystemExit, message
	return image, image.get_rect()

def main():
	set = Set('Set', 745, 555, 120)

if __name__ == '__main__':
	main()